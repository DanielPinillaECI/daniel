#include "muestra_datos.h"
#include "ui_muestra_datos.h"
#include "sensor.h"
#include <chrono>
#include <ctime>
#include <sstream>
#include <iostream>
#include "QDebug"
#include "QMessageBox"


int cont = 0;
MUESTRA_DATOS::MUESTRA_DATOS(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MUESTRA_DATOS)
{
    ui->setupUi(this);
    CreaTabla();
    _tmr = new QTimer();
    _tmr->setInterval( 50 );
    connect( _tmr, SIGNAL(timeout()), this, SLOT(leerSensores()) );
    _tmr->start();

    ActualizarFechaFromSO();

    std::cout << _fecha << std::endl;
    _itera = 0;
    _prom_Tem[0] = _prom_Tem[1] = _prom_Tem[2] = 0.;
    _prom_Viento[0] = _prom_Viento[1] = 0.;
    _prom_Preci = 0.;


    actualizarGUI();
}
MUESTRA_DATOS::~MUESTRA_DATOS()
{
    delete ui;
    delete _tmr;
}

void MUESTRA_DATOS::CreaTabla()
{
    QString consulta;
    consulta.append("CREATE TABLE IF NOT EXISTS SENSORES_BASE_DE_DATOS("
                    "temperatura,"
                    "humedad ,"
                    "max_temp,"
                    "min_temp,"
                    "max_hum,"
                    "min_hum,"
                    "max_dir,"
                    "min_dir,"
                    "max_vel,"
                    "min_vel,"
                    "max_luz,"
                    "min_luz,"
                    "max_pre,"
                    "min_pre,"
                    "velocidad_viento ,"
                    "direccion_viento ,"
                    "precipitacion ,"
                    "intensidad_luz "
                    ");");
    QSqlQuery crear;
    crear.prepare(consulta);
    if(crear.exec())
    {
        qDebug()<<"Tabla datos del sensor Creada";
    }else
    {
        qDebug()<<"Tabla datos del sensor no creada"<<crear.lastError();
    }
}

void MUESTRA_DATOS::agregar_datos(){

    QSqlQuery insertar_db;
    QString temperatura=ui->TEMPE->text();
    QString humedad=ui->HUME->text();
    QString velocidad_viento=ui->VEL->text();
    QString direccion_viento=ui->DIREC->text();
    QString precipitacion=ui->PRECI->text();
    QString intensidad_luz=ui->LUZ->text();

    QString max_temp=ui->MAX_TEMP->text();
    QString min_temp=ui->MIN_TEMP->text();
    QString max_dir=ui->MAX_DIR_VI->text();
    QString min_dir=ui->MIN_DIR_VI->text();
    QString max_luz=ui->MAX_INT_LUZ->text();
    QString min_luz=ui->MIN_INT_LUZ->text();
    QString max_vel=ui->MAX_VEL_VI->text();
    QString min_vel=ui->MIN_VEL_VI->text();
    QString max_pre=ui->MAX_PRECIPI->text();
    QString min_pre=ui->MIN_PRECIPI->text();
    QString max_hum=ui->MAX_HUM->text();
    QString min_hum=ui->MIN_HUM->text();

    qDebug()<<temperatura;
    qDebug()<<humedad;
    qDebug()<<velocidad_viento;
    qDebug()<<direccion_viento;
    qDebug()<<precipitacion;
    qDebug()<<intensidad_luz;

    qDebug()<<max_temp;
    qDebug()<<min_temp;
    qDebug()<<max_dir;
    qDebug()<<min_dir;
    qDebug()<<max_luz;
    qDebug()<<min_luz;
    qDebug()<<max_vel;
    qDebug()<<min_vel;
    qDebug()<<max_pre;
    qDebug()<<min_pre;
    qDebug()<<max_hum;
    qDebug()<<min_hum;

    QSqlQuery insert_db;
    insertar_db.prepare("INSERT INTO SENSORES_BASE_DE_DATOS(temperatura,humedad,velocidad_viento,direccion_viento,precipitacion,intensidad_luz,max_temp,min_temp,max_dir,min_dir,max_luz,min_luz,max_vel,min_vel,max_pre,min_pre,max_hum,min_hum)"
                    "VALUES (:temperatura,:humedad,:velocidad_viento,:direccion_viento,:precipitacion,:intensidad_luz,:max_temp,:min_temp,:max_dir,:min_dir,:max_luz,:min_luz,:max_vel,:min_vel,:max_pre,:min_pre,:max_hum,:min_hum)");
    insertar_db.bindValue(":temperatura",temperatura);
    insertar_db.bindValue(":humedad",humedad);
    insertar_db.bindValue(":velocidad_viento",velocidad_viento);
    insertar_db.bindValue(":direccion_viento",direccion_viento);
    insertar_db.bindValue(":precipitacion",precipitacion);
    insertar_db.bindValue(":intensidad_luz",intensidad_luz);

    insertar_db.bindValue(":max_temp",max_temp);
    insertar_db.bindValue(":min_temp",min_temp);
    insertar_db.bindValue(":max_dir",max_dir);
    insertar_db.bindValue(":min_dir",min_dir);
    insertar_db.bindValue(":max_luz",max_luz);
    insertar_db.bindValue(":min_luz",min_luz);
    insertar_db.bindValue(":max_vel",max_vel);
    insertar_db.bindValue(":min_vel",min_vel);
    insertar_db.bindValue(":max_pre",max_pre);
    insertar_db.bindValue(":min_pre",min_pre);
    insertar_db.bindValue(":max_hum",max_hum);
    insertar_db.bindValue(":min_hum",min_hum);
    if(insertar_db.exec())
    {
            qDebug()<<"Datos ingresados a la tabla";
    }
    else
    {
        qDebug()<<"Error al ingresar los datos"<<insertar_db.lastError();
    }
}

void MUESTRA_DATOS::actualizarGUI(){

    ui->HORA->setText( QString::number( _hr ) );
    ui->SEG->setText( QString::number( _min ));
    ui->TEMPE->setText( QString::number( _tem.temperatura() ) + " °C");
    ui->HUME->setText( QString::number( _tem.humedad() ) +" %");
    ui->VEL->setText( QString::number( _viento.velocidad() ) +" km/h");
    ui->DIREC->setText( QString::number( _viento.direccion() ) + " °");
    ui->PRECI->setText( QString::number( _preci.leerDato() ) +" mm/día");
    ui->LUZ->setText(QString::number( _tem.luz() ) +" lummen");
    ui->PROM_TEMP->setText( QString::number( _prom_Tem[0] ) + " °C");
    ui->PROM_VEL_VI->setText( QString::number( _prom_Viento[1] ) +" km/h");
    ui->PROM_HUM->setText( QString::number( _prom_Tem[1] ) +" %");
    ui->PROM_PRECIPI->setText( QString::number( _prom_Preci ) +" mm/día");
    ui->PROM_DIR_VI->setText( QString::number( _prom_Viento[0] ) + " °");
    ui->PROM_INT_LUZ->setText(QString::number( _prom_Tem[2] ) +" lummen");
    ui->MAX_TEMP->setText(QString::number( max_temp ) +" °C");
    ui->MIN_TEMP->setText(QString::number( min_temp ) +" °C");
    ui->MAX_VEL_VI->setText(QString::number( max_vel) +" km/h");
    ui->MIN_VEL_VI->setText(QString::number( min_vel ) +" km/h");
    ui->MAX_HUM->setText(QString::number( max_hum ) +" %");
    ui->MIN_HUM->setText(QString::number( min_hum ) +" %");
    ui->MAX_PRECIPI->setText(QString::number( max_pre) +" mm/día");
    ui->MIN_PRECIPI->setText(QString::number( min_pre) +" mm/día");
    ui->MAX_DIR_VI->setText(QString::number( max_dir) + " °");
    ui->MIN_DIR_VI->setText(QString::number( min_dir) + " °");
    ui->MAX_INT_LUZ->setText(QString::number( max_luz) +" lummen");
    ui->MIN_INT_LUZ->setText(QString::number( min_luz ) +" lummen");
}

int estado;
void MUESTRA_DATOS::on_IZQUIERDA_clicked()
{
    if (cont>0){
    cont = cont-1;
    }
    else{}
    estado=cont;
    estados(cont);
}

void MUESTRA_DATOS::on_DERECHA_clicked()
{
    if (cont<=2)
    {
    cont = cont+1;
    }
    else
    {
    cont = cont-2;
    }
    estado=cont;
    estados(cont);
}

void MUESTRA_DATOS::estados(int& cont)
{
}

void MUESTRA_DATOS::leerSensores(){


    agregar_datos();


    _tem.actualizar();
    _prom_Tem[0] += _tem.temperatura();
    _prom_Tem[1] += _tem.humedad();
    _prom_Tem[2] += _tem.luz();

    _viento.actualizar();
    _prom_Viento[0] += _viento.velocidad();
    _prom_Viento[1] += _viento.direccion();

    _preci.actualizar();
    _prom_Preci += _preci.leerDato();


    //creamos vectores para evaluar máximos y mínimos


    int cont = 1;

    double max_temp;
    double min_temp;

    //validamos máximos y mínimos de los datos de los sensores

    for(cont=1;cont<=12;cont++){
            if (cont == 1){
                max_temp = _tem.temperatura();
                min_temp = _tem.temperatura();
            }
            else
            {
                if(_tem.temperatura() > max_temp){
                    max_temp = _tem.temperatura();
                }
                if(_tem.temperatura() < min_temp){
                    min_temp = _tem.temperatura();
                }
                if(_tem.humedad() > max_temp){
                    max_hum = _tem.humedad();
                }
                if(_tem.humedad() < min_temp){
                    min_hum = _tem.humedad();
                }
                if(_viento.velocidad() > max_temp){
                    max_vel = _viento.velocidad();
                }
                if(_viento.velocidad() < min_temp){
                    min_vel = _viento.velocidad();
                }
                if(_tem.luz() > max_temp){
                    max_luz = _tem.luz();
                }
                if(_tem.luz() < min_temp){
                    min_luz = _tem.luz();
                }
                if(_viento.direccion() > max_temp){
                    max_dir = _viento.direccion();
                }
                if(_viento.direccion() < min_temp){
                    min_dir = _viento.direccion();
                }
                if(_preci.leerDato() > max_temp){
                    max_pre = _preci.leerDato();
                }
                if(_preci.leerDato() < min_temp){
                    min_pre = _preci.leerDato();
                }
            }
        }




    // Contador de cada 5 seg. Un minuto son 12.
    _itera++;
    if( _itera == 60 ){
        _itera = 0;
        _min++;
        if( _min == 60 ){
            _min = 0;
            _hr++;
           if( _hr == 24) {
               _hr = 0;
               ActualizarFechaFromSO();
           }
        }
        // Calculando los promedios de minuto


        _prom_Tem[0] /= 12.;
        _prom_Tem[1] /= 12.;

        _prom_Viento[0] /= 12.;
        _prom_Viento[1] /= 12.;

        // Actualizando GUI
        actualizarGUI();

        // VARIABLES DE PROMEDIO
        _prom_Tem[0] = _prom_Tem[1] = _prom_Tem [2] = 0.;
        _prom_Viento[0] = _prom_Viento[1] = 0.;
        _prom_Preci = 0.;
    }

}

void MUESTRA_DATOS::ActualizarFechaFromSO()
{
    time_t now = time(0);
    tm *ltm = localtime(&now);
    _hr = ltm->tm_hour;
    _min = ltm->tm_min;

    std::stringstream fecha;
    fecha << ltm->tm_mday << "/" << ltm->tm_mon + 1  << "/" << ltm->tm_year + 1900;
    _fecha = fecha.str();
}

