#ifndef SENSOR_H
#define SENSOR_H

#include <iostream>
#include <string>
#include <sstream>
#include <cmath>

using namespace std;

class Sensor{

private:

//VARIABLES TIPO PRIVATE

    double _dato;

    int _limite;

    double _max;

    double _min;

    double _acum;

    int _cant;

    int _periodo;

    int _conteo;

    int _vmin;

public:

     //FUNCIONES
    Sensor(int limite = 0, int vmin = 0, int periodo = 0, double dato = 0., double max = -3000, double min = 3000, double acum = 0, int cant = 0){
        _dato = dato;
        _limite = limite;
        _periodo = periodo;
        _acum = acum;
        _max = max;
        _min = min;
        _cant = cant;
        _vmin = vmin;
    }

    double leerDato(){ return _dato; }

    void actu(int contador, int periodo);

    double prom () {return _acum/_cant;}

    double max() {return _max;}

    double min () {return _min;}

    void reiniciar ();

};

class Temp: public Sensor{
public:

    Temp():Sensor(55, -10){}
};

class Humedad: public Sensor{
public:

    Humedad():Sensor(100, 0){}
};

class Velocidad_vi: public Sensor{
public:

    Velocidad_vi():Sensor(40, 0){}
};

class Dir_Viento: public Sensor{
public:

    Dir_Viento():Sensor(360, -180){}
};

class Precipi: public Sensor{
public:

    Precipi():Sensor(50, 0){}
};

class Int: public Sensor{
public:

    Int():Sensor(2000, 0){}
};

#endif // SENSOR_H
